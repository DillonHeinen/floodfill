1. Extract files and navigate to correct directory.
2. Execute make command.
3. Type ./flood_fill [filename] to receive prompt.
4. Follow directions on prompt.